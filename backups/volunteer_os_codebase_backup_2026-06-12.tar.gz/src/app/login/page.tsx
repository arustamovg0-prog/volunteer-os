'use client';

import { Suspense } from 'react';
import { useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowRight, Eye, EyeOff, Loader2, LockKeyhole, ShieldCheck, UserRound } from 'lucide-react';

type LoginRole = 'manager' | 'volunteer';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialRole = searchParams.get('role') === 'volunteer' ? 'volunteer' : 'manager';
  const next = searchParams.get('next');

  const [role, setRole] = useState<LoginRole>(initialRole);
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const copy = useMemo(() => {
    if (role === 'volunteer') {
      return {
        title: 'Вход для волонтеров',
        subtitle: 'Доступ к задачам, проектам, чатам, отчетам и личному профилю.',
        accent: 'emerald',
        defaultHint: 'Например: ivan',
      };
    }

    return {
      title: 'Вход для координаторов',
      subtitle: 'Доступ к операционному дашборду, CRM, проектам, аналитике и базе знаний.',
      accent: 'slate',
      defaultHint: 'Например: alexey',
    };
  }, [role]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role, login, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Не удалось войти');
        setLoading(false);
        return;
      }

      const user = data.user;
      localStorage.setItem('currentUserId', user.id);
      localStorage.setItem('currentUserName', user.full_name);
      localStorage.setItem('currentUserRole', user.role);

      if (user.role === 'volunteer') {
        localStorage.setItem('volunteerId', user.id);
        localStorage.setItem('volunteerName', user.full_name);
        localStorage.setItem('volunteerId', user.id);
        localStorage.setItem('volunteerName', user.full_name);
        window.dispatchEvent(new Event('volunteer-session-change'));
      }

      window.dispatchEvent(new Event('auth-session-change'));
      router.replace(next || data.redirectTo || (user.role === 'volunteer' ? '/volunteer-dashboard' : '/dashboard'));
      router.refresh();
    } catch {
      setError('Ошибка соединения. Проверьте, что платформа запущена.');
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#F9FAFB] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-xl p-6 space-y-6">
        <div className="text-center space-y-3">
          <div className={`mx-auto w-14 h-14 rounded-2xl ${role === 'volunteer' ? 'bg-emerald-600' : 'bg-slate-900'} flex items-center justify-center text-white shadow-md`}>
            {role === 'volunteer' ? <UserRound className="w-7 h-7" /> : <ShieldCheck className="w-7 h-7" />}
          </div>
          <div className="space-y-1">
            <h1 className="text-xl font-extrabold text-slate-950">{copy.title}</h1>
            <p className="text-xs text-slate-500 leading-relaxed">{copy.subtitle}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1 border border-slate-200">
          <button
            type="button"
            onClick={() => setRole('manager')}
            className={`rounded-lg py-2 text-[11px] font-bold uppercase tracking-wide transition-all ${role === 'manager' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            Координатор
          </button>
          <button
            type="button"
            onClick={() => setRole('volunteer')}
            className={`rounded-lg py-2 text-[11px] font-bold uppercase tracking-wide transition-all ${role === 'volunteer' ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            Волонтер
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Логин</label>
            <input
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              placeholder={copy.defaultHint}
              autoComplete="username"
              className="w-full px-3.5 py-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
            />
          </div>

          <div className="space-y-1.5">
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Пароль</label>
            <div className="relative">
              <LockKeyhole className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type={showPassword ? 'text' : 'password'}
                placeholder="Введите пароль"
                autoComplete="current-password"
                className="w-full pl-10 pr-11 py-3 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword((value) => !value)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                aria-label={showPassword ? 'Скрыть пароль' : 'Показать пароль'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700">
              {error}
            </div>
          )}

          <button
            disabled={loading || !login.trim() || !password}
            className={`w-full py-3 rounded-xl text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all disabled:opacity-60 disabled:cursor-not-allowed ${role === 'volunteer' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-slate-900 hover:bg-slate-800'}`}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Проверка доступа...
              </>
            ) : (
              <>
                Войти
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {role === 'volunteer' && (
          <div className="text-center text-xs text-slate-500">
            Нет аккаунта?{' '}
            <button onClick={() => router.push('/volunteer-dashboard/auth')} className="font-bold text-emerald-700 hover:text-emerald-800">
              Зарегистрироваться
            </button>
          </div>
        )}
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={
      <main className="min-h-screen bg-[#F9FAFB] flex items-center justify-center p-4">
        <Loader2 className="w-7 h-7 animate-spin text-slate-900" />
      </main>
    }>
      <LoginForm />
    </Suspense>
  );
}
