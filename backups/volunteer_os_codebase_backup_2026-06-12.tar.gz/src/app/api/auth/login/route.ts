import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { AUTH_COOKIE_NAME, createSessionToken, rateLimitRequest, verifyPassword } from '@/lib/security';

function publicSession(user: any) {
  return {
    user: {
      id: user.id,
      role: user.role,
      full_name: user.full_name,
      login: user.login,
      phone: user.phone || null,
    },
    redirectTo: user.role === 'volunteer' ? '/volunteer-dashboard' : '/dashboard',
  };
}

export async function POST(req: NextRequest) {
  try {
    const rateLimitError = rateLimitRequest(req, 'login', 8, 60 * 1000);
    if (rateLimitError) return rateLimitError;

    const body = await req.json();
    const login = String(body.login || '').trim().toLowerCase();
    const password = String(body.password || '');
    const expectedRole = body.role ? String(body.role) : null;

    if (!login || !password) {
      return NextResponse.json({ error: 'Login and password are required' }, { status: 400 });
    }

    const user = await db.getUserByLogin(login);
    if (!user || !verifyPassword(password, user.password_hash)) {
      return NextResponse.json({ error: 'Неверный логин или пароль' }, { status: 401 });
    }

    if (expectedRole === 'volunteer' && user.role !== 'volunteer') {
      return NextResponse.json({ error: 'Этот аккаунт не является волонтерским' }, { status: 403 });
    }

    if (expectedRole === 'manager' && !['admin', 'manager'].includes(user.role)) {
      return NextResponse.json({ error: 'Этот аккаунт не является аккаунтом координатора' }, { status: 403 });
    }

    const token = createSessionToken({
      userId: user.id,
      role: user.role,
      fullName: user.full_name,
      login: user.login || login,
    });

    const res = NextResponse.json(publicSession(user));
    res.cookies.set(AUTH_COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.VOLUNTEER_OS_SECURE_COOKIES === 'true',
      path: '/',
      maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  } catch (error) {
    console.error('Login failed:', error);
    return NextResponse.json({ error: 'Login failed' }, { status: 500 });
  }
}
