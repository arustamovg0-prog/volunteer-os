import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requirePrivilegedRequest } from '@/lib/security';
import fs from 'fs';
import path from 'path';

export async function GET(req: NextRequest) {
  try {
    const items = await db.getArchiveItems();
    return NextResponse.json(items);
  } catch (error) {
    console.error('Failed to fetch archive items:', error);
    return NextResponse.json({ error: 'Failed to fetch archive items' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === 'cleanup') {
      const authError = requirePrivilegedRequest(req, ['admin', 'manager']);
      if (authError) return authError;

      // Find empty chats and delete them
      // Load data manually from JSON DB file for direct mutation
      const dbPath = path.join(process.cwd(), 'volunteer_os_db.json');
      if (!fs.existsSync(dbPath)) {
        return NextResponse.json({ deletedCount: 0, message: 'Database file not found' });
      }

      const raw = fs.readFileSync(dbPath, 'utf8');
      const data = JSON.parse(raw);

      const initialChatCount = data.chats?.length || 0;
      if (initialChatCount === 0) {
        return NextResponse.json({ deletedCount: 0, message: 'No chats to clean' });
      }

      // Filter chats that have at least one message
      const activeChats = data.chats.filter((chat: any) => {
        const hasMessages = data.chat_messages?.some((msg: any) => msg.chat_id === chat.id);
        // Keep project/mgmt chats if they have messages, or project chats that are active
        return hasMessages;
      });

      const deletedCount = initialChatCount - activeChats.length;
      data.chats = activeChats;

      fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), 'utf8');

      return NextResponse.json({
        success: true,
        deletedCount,
        message: `Успешно удалено пустых чатов: ${deletedCount}`
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Failed to run archive cleanup:', error);
    return NextResponse.json({ error: 'Failed to run cleanup' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const authError = requirePrivilegedRequest(req, ['admin', 'manager']);
    if (authError) return authError;

    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Archive item ID is required' }, { status: 400 });
    }

    await db.deleteArchiveItem(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete archive item:', error);
    return NextResponse.json({ error: 'Failed to delete archive item' }, { status: 500 });
  }
}
