'use client';

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

type AuthRole = 'admin' | 'manager' | 'volunteer';

interface AuthGuardProps {
  allowedRoles: AuthRole[];
  children: React.ReactNode;
}

export default function AuthGuard({ allowedRoles, children }: AuthGuardProps) {
  const router = useRouter();
  const pathname = usePathname();
  const [status, setStatus] = useState<'checking' | 'allowed'>('checking');

  useEffect(() => {
    let isMounted = true;

    async function checkSession() {
      if (pathname === '/volunteer-dashboard/auth') {
        setStatus('allowed');
        return;
      }

      try {
        const res = await fetch('/api/auth/me', { credentials: 'include' });
        if (!res.ok) {
          router.replace(`/login?next=${encodeURIComponent(pathname || '/')}`);
          return;
        }

        const data = await res.json();
        const user = data.user;
        if (!user || !allowedRoles.includes(user.role)) {
          router.replace(user?.role === 'volunteer' ? '/volunteer-dashboard' : '/dashboard');
          return;
        }

        localStorage.setItem('currentUserId', user.id);
        localStorage.setItem('currentUserName', user.full_name);
        localStorage.setItem('currentUserRole', user.role);

        if (user.role === 'volunteer') {
          localStorage.setItem('volunteerId', user.id);
          localStorage.setItem('volunteerName', user.full_name);
          window.dispatchEvent(new Event('volunteer-session-change'));
        }

        window.dispatchEvent(new Event('auth-session-change'));
        if (isMounted) setStatus('allowed');
      } catch {
        router.replace(`/login?next=${encodeURIComponent(pathname || '/')}`);
      }
    }

    checkSession();
    return () => {
      isMounted = false;
    };
  }, [allowedRoles, pathname, router]);

  if (status !== 'allowed') {
    return (
      <div className="min-h-screen bg-[#F9FAFB] flex items-center justify-center">
        <Loader2 className="h-7 w-7 animate-spin text-slate-900" />
      </div>
    );
  }

  return <>{children}</>;
}
