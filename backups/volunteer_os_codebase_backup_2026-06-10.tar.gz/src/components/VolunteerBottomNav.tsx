'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { ClipboardList, BookOpen, LogOut, Folder, MessageSquare, Building2, User } from 'lucide-react';

export default function VolunteerBottomNav() {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = () => {
    if (confirm('Вы уверены, что хотите выйти из кабинета волонтера?')) {
      localStorage.removeItem('volunteerId');
      router.push('/');
    }
  };

  const navItems = [
    { name: 'Задачи', path: '/volunteer-dashboard', icon: ClipboardList },
    { name: 'Проекты', path: '/volunteer-dashboard/projects', icon: Folder },
    { name: 'Чаты', path: '/volunteer-dashboard/chats', icon: MessageSquare },
    { name: 'Профиль', path: '/volunteer-dashboard/profile', icon: User },
    { name: 'Организации', path: '/volunteer-dashboard/organizations', icon: Building2 },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/90 backdrop-blur-xl border-t border-slate-200 flex items-center justify-around px-4 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]">
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = pathname === item.path;
        
        return (
          <Link
            key={item.path}
            href={item.path}
            className={`flex flex-col items-center gap-1 transition-all ${
              isActive ? 'text-slate-900 scale-105 font-semibold' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{item.name}</span>
          </Link>
        );
      })}

      <button
        onClick={handleLogout}
        className="flex flex-col items-center gap-1 text-slate-400 hover:text-red-500 transition-all cursor-pointer"
      >
        <LogOut className="w-5 h-5" />
        <span className="text-[10px] font-medium">Выйти</span>
      </button>
    </div>
  );
}
