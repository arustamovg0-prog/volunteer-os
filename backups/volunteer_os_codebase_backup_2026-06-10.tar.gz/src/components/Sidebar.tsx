'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  FolderGit2, 
  Users2, 
  BookOpen, 
  FileSpreadsheet, 
  ShieldCheck,
  UserCircle2,
  MessageSquare,
  Building2,
  Settings,
  Boxes,
  Trophy,
  Key,
  Archive,
  Handshake,
  FileText,
  Calculator,
  Sparkles,
  AlertTriangle
} from 'lucide-react';

interface SidebarProps {
  currentRole?: string;
  fullName?: string;
}

export default function Sidebar({ 
  currentRole = 'manager', 
  fullName = 'Алексей Смирнов'
}: SidebarProps) {
  const pathname = usePathname();
  const [role, setRole] = useState(currentRole);
  const [name, setName] = useState(fullName);

  useEffect(() => {
    const loadSimulatedRole = () => {
      const savedRole = localStorage.getItem('simulatedRole');
      if (savedRole) {
        setRole(savedRole);
        setName(savedRole === 'admin' ? 'Дмитрий Админов' : 'Алексей Смирнов');
      }
    };

    // Load initial values
    loadSimulatedRole();

    // Listen to updates in other parts of the app
    window.addEventListener('storage', loadSimulatedRole);
    window.addEventListener('simulated-role-change', loadSimulatedRole);

    return () => {
      window.removeEventListener('storage', loadSimulatedRole);
      window.removeEventListener('simulated-role-change', loadSimulatedRole);
    };
  }, []);

  const menuItems = [
    { name: 'Обзор панелей', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Проекты & Канбан', path: '/dashboard/projects', icon: FolderGit2 },
    { name: 'Волонтеры CRM', path: '/dashboard/volunteers', icon: Users2 },
    { name: 'Организации', path: '/dashboard/organizations', icon: Building2 },
    { name: 'Склад & Инвентарь', path: '/dashboard/inventory', icon: Boxes },
    { name: 'Рейтинги & KPI', path: '/dashboard/leaderboards', icon: Trophy },
    { name: 'Партнеры CRM', path: '/dashboard/partners', icon: Handshake },
    { name: 'База знаний', path: '/dashboard/kb', icon: BookOpen },
    { name: 'Чаты & Поддержка', path: '/dashboard/chats', icon: MessageSquare },
    { name: 'Цифровой Архив', path: '/dashboard/archive', icon: Archive },
    { name: 'Менеджер Паролей', path: '/dashboard/access-keys', icon: Key },
    { name: 'HR-Документы', path: '/dashboard/hr-documents', icon: FileText },
    { name: 'SMM-Ассистент', path: '/dashboard/smm-assistant', icon: Sparkles },
    { name: 'Чрезвычайные Ситуации', path: '/dashboard/alerts', icon: AlertTriangle },
    ...(role === 'admin' ? [
      { name: 'Дидокс Финансы', path: '/dashboard/finance', icon: Calculator },
      { name: 'Отчеты & Экспорт', path: '/dashboard/reports', icon: FileSpreadsheet },
      { name: 'Настройки бота', path: '/dashboard/bot-settings', icon: Settings }
    ] : []),
  ];

  return (
    <aside className="w-64 border-r border-slate-200 bg-white flex flex-col h-screen sticky top-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-100 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center shadow-sm">
          <span className="font-bold text-white text-md">V</span>
        </div>
        <div>
          <h1 className="font-bold text-slate-900 text-sm tracking-wide">Volunteer OS</h1>
          <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Операционное Управление</p>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.path || (item.path !== '/dashboard' && pathname.startsWith(item.path));
          
          return (
            <Link
              key={item.path}
              href={item.path}
              className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 group ${
                isActive 
                  ? 'bg-slate-900 text-white shadow-sm' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon className={`w-4 h-4 transition-transform group-hover:scale-105 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-600'}`} />
              {item.name}
            </Link>
          );
        })}
      </nav>

      {/* Admin indicator if applicable */}
      {role === 'admin' && (
        <div className="mx-4 mb-2 p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2 text-slate-700">
          <ShieldCheck className="w-4 h-4 shrink-0 text-slate-900" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Режим Директора</span>
        </div>
      )}

      {/* User Footer Profile */}
      <div className="p-4 border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center">
            <UserCircle2 className="w-5 h-5 text-slate-500" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold text-slate-900 truncate">{name}</p>
            <p className="text-[10px] text-slate-400 truncate uppercase font-semibold tracking-wider">
              {role === 'admin' ? 'Руководитель' : 'Координатор'}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}
