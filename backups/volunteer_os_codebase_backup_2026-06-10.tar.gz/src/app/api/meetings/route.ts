import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const projectId = searchParams.get('projectId');

    let meetings = await db.getMeetings();

    if (projectId) {
      meetings = meetings.filter(m => m.project_id === projectId);
    }

    // Sort by scheduled date ascending
    meetings.sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime());

    return NextResponse.json(meetings);
  } catch (error) {
    console.error('Failed to fetch meetings:', error);
    return NextResponse.json({ error: 'Failed to fetch meetings' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, description, scheduled_at, link, project_id, created_by } = body;

    if (!title || !scheduled_at) {
      return NextResponse.json({ error: 'Title and scheduled time are required' }, { status: 400 });
    }

    const newMeeting = await db.createMeeting({
      title,
      description: description || '',
      scheduled_at,
      link: link || '',
      project_id: project_id || null,
      created_by: created_by || null
    });

    return NextResponse.json(newMeeting, { status: 201 });
  } catch (error) {
    console.error('Failed to create meeting:', error);
    return NextResponse.json({ error: 'Failed to create meeting' }, { status: 500 });
  }
}
