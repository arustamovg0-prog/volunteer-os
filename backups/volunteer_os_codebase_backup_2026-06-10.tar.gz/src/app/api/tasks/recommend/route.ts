import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const volunteerId = searchParams.get('volunteerId');

    if (!volunteerId) {
      return NextResponse.json({ error: 'Volunteer ID parameter is required' }, { status: 400 });
    }

    const recommendations = await db.getRecommendations(volunteerId);
    
    // Enrich tasks with project details for rendering context
    const enrichedRecommendations = recommendations.map((task: any) => {
      const project = (db as any).data.projects.find((p: any) => p.id === task.project_id);
      const org = project ? (db as any).data.organizations.find((o: any) => o.id === project.org_id) : null;
      return {
        ...task,
        project_title: project ? project.title : 'Неизвестный проект',
        org_name: org ? org.name : 'Ассоциация',
        org_category: org ? org.category : 'Социальная помощь'
      };
    });

    return NextResponse.json({
      recommendations: enrichedRecommendations
    });
  } catch (error) {
    console.error('Failed to get task recommendations:', error);
    return NextResponse.json({ error: 'Failed to get task recommendations' }, { status: 500 });
  }
}
