import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const chatId = searchParams.get('chatId');

    if (!chatId) {
      return NextResponse.json({ error: 'Chat ID is required' }, { status: 400 });
    }

    const messages = await db.getChatMessages(chatId);
    
    // Sort messages by creation time ascending
    messages.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

    return NextResponse.json(messages);
  } catch (error) {
    console.error('Failed to fetch chat messages:', error);
    return NextResponse.json({ error: 'Failed to fetch chat messages' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { chatId, senderId, senderName, senderRole, text } = body;

    if (!chatId || !senderId || !senderName || !senderRole || !text) {
      return NextResponse.json({ error: 'All fields are required (chatId, senderId, senderName, senderRole, text)' }, { status: 400 });
    }

    const newMessage = await db.createChatMessage({
      chat_id: chatId,
      sender_id: senderId,
      sender_name: senderName,
      sender_role: senderRole,
      text: text.trim()
    });

    return NextResponse.json(newMessage, { status: 201 });
  } catch (error) {
    console.error('Failed to post message:', error);
    return NextResponse.json({ error: 'Failed to post message' }, { status: 500 });
  }
}
