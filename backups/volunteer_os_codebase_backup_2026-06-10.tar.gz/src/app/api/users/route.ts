import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const role = searchParams.get('role');

    let users = await db.getUsers();

    if (role) {
      users = users.filter(u => u.role === role);
    }

    // Sort by rating descending
    users.sort((a, b) => b.rating - a.rating);

    return NextResponse.json(users);
  } catch (error) {
    console.error('Failed to fetch users:', error);
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { role, full_name, telegram_id, phone } = body;

    if (!full_name || !role) {
      return NextResponse.json({ error: 'Role and full name are required' }, { status: 400 });
    }

    const newUser = await db.createUser({
      role,
      full_name,
      telegram_id: telegram_id ? Number(telegram_id) : null,
      phone: phone || null
    });

    return NextResponse.json(newUser, { status: 201 });
  } catch (error) {
    console.error('Failed to create user:', error);
    return NextResponse.json({ error: 'Failed to create user' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    const updatedUser = await db.updateUser(id, updates);
    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Failed to update user:', error);
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 });
  }
}
