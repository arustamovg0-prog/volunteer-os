import Sidebar from '@/components/Sidebar';
import TelegramSimulator from '@/components/TelegramSimulator';

export const metadata = {
  title: 'Volunteer OS — Dashboard',
  description: 'Volunteer OS management dashboard',
};

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen relative bg-[#F9FAFB] text-[#0F172A]">
      {/* Sidebar Navigation */}
      <Sidebar currentRole="manager" fullName="Алексей Смирнов" />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <main className="flex-1 p-8 overflow-y-auto max-h-screen">
          {children}
        </main>
      </div>

      {/* Persistent Telegram Bot Simulator */}
      <TelegramSimulator />
    </div>
  );
}
